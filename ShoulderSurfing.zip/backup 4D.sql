-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.11-MariaDB


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema shouldersurfing
--

CREATE DATABASE IF NOT EXISTS shouldersurfing;
USE shouldersurfing;

--
-- Definition of table `addbeneficiary`
--

DROP TABLE IF EXISTS `addbeneficiary`;
CREATE TABLE `addbeneficiary` (
  `username` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `b_Acc` varchar(45) NOT NULL,
  `pin_no` varchar(45) NOT NULL,
  `mobile_no` varchar(45) NOT NULL,
  PRIMARY KEY (`b_Acc`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addbeneficiary`
--

/*!40000 ALTER TABLE `addbeneficiary` DISABLE KEYS */;
INSERT INTO `addbeneficiary` (`username`,`name`,`nickname`,`ifsc`,`b_Acc`,`pin_no`,`mobile_no`) VALUES 
 ('kkE+sPZhG3lRKTzF3JscUA==','V0WVJYCq2AYqEfVLhqxOog==','WAkpze0cu2IXCo6kQUjl7Q==','s9DqpcoJZdAGS9KABNj/iQ==','2CTCxhdgANqg+Eln2kYXRg==','uBEMAAR3aLNBQlc0oJ1I3A==','PLvvlNdDl6U2xUZ74Uen7A==');
/*!40000 ALTER TABLE `addbeneficiary` ENABLE KEYS */;


--
-- Definition of table `bankdetails`
--

DROP TABLE IF EXISTS `bankdetails`;
CREATE TABLE `bankdetails` (
  `accno` varchar(100) NOT NULL,
  `bname` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `hname` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `age` varchar(45) NOT NULL,
  `panno` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `amount` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  PRIMARY KEY (`accno`,`uname`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bankdetails`
--

/*!40000 ALTER TABLE `bankdetails` DISABLE KEYS */;
INSERT INTO `bankdetails` (`accno`,`bname`,`ifsc`,`type`,`hname`,`gender`,`age`,`panno`,`mobile`,`email`,`amount`,`dob`,`uname`) VALUES 
 ('gFQXf8iBio0HQMRKPREJXw==','tyA4ta5NtylvNeifl9xhQw==','VGwmldeLzg5NtGdIaqGWZw==','7FCzts3ZuMAyinkacO6KhQ==','eTae8I77t2EnYeJqPTV8ng==','HYkoxbD9Ts74J4NbvMKoBg==','SHD+UVuKh8PLGc7Qs7/OzA==','SHD+UVuKh8PLGc7Qs7/OzA==','tYWd8nVG0/AgHYFBO9cq+g==','owG2LgrrFlH2Uc3RromPykUkkdXz2cs3QW7EK7rmy7M=','owky2G7wdpBvnbMhoWewRQ==','kGryC8/e33PJoDTxrWIP23EqT9ENvL5ByoQI6/ZBwRc=','kkE+sPZhG3lRKTzF3JscUA==');
/*!40000 ALTER TABLE `bankdetails` ENABLE KEYS */;


--
-- Definition of table `color_registration`
--

DROP TABLE IF EXISTS `color_registration`;
CREATE TABLE `color_registration` (
  `user_id` varchar(45) NOT NULL,
  `red_color` int(11) NOT NULL,
  `blue_color` int(11) NOT NULL,
  `green_color` int(11) NOT NULL,
  `pink_color` int(11) NOT NULL,
  `black_color` int(11) NOT NULL,
  `orange_color` int(11) NOT NULL,
  `cyan_color` int(11) NOT NULL,
  `magenta_color` int(11) NOT NULL,
  `user_status` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `color_registration`
--

/*!40000 ALTER TABLE `color_registration` DISABLE KEYS */;
INSERT INTO `color_registration` (`user_id`,`red_color`,`blue_color`,`green_color`,`pink_color`,`black_color`,`orange_color`,`cyan_color`,`magenta_color`,`user_status`) VALUES 
 ('pramod',2,1,3,5,4,6,7,8,1);
/*!40000 ALTER TABLE `color_registration` ENABLE KEYS */;


--
-- Definition of table `receivemoney`
--

DROP TABLE IF EXISTS `receivemoney`;
CREATE TABLE `receivemoney` (
  `sname` varchar(200) DEFAULT NULL,
  `rname` varchar(45) DEFAULT NULL,
  `ifsc` varchar(45) DEFAULT NULL,
  `s_acc` varchar(45) DEFAULT NULL,
  `r_acc` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receivemoney`
--

/*!40000 ALTER TABLE `receivemoney` DISABLE KEYS */;
INSERT INTO `receivemoney` (`sname`,`rname`,`ifsc`,`s_acc`,`r_acc`,`amount`) VALUES 
 ('aLmyBAYff/vcGZAUEv9ulw==','iji/sfAVausIPsrwxHy/jw==','LuoeFpaqgyOALdPQW57HIg==','GSFHKdjvRJJrs8HUHap1HA==','Gipxpl7iWL62b/ldd5suEA==','6cLg06379TwqYpv/M45c7w=='),
 ('kkE+sPZhG3lRKTzF3JscUA==','V0WVJYCq2AYqEfVLhqxOog==','s9DqpcoJZdAGS9KABNj/iQ==','gFQXf8iBio0HQMRKPREJXw==','2CTCxhdgANqg+Eln2kYXRg==','6SmR7JVHQXLrWu8A0w+ehg==');
/*!40000 ALTER TABLE `receivemoney` ENABLE KEYS */;


--
-- Definition of table `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE `register` (
  `Name` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `EmailId` varchar(50) NOT NULL,
  `MobileNo` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`EmailId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

/*!40000 ALTER TABLE `register` DISABLE KEYS */;
/*!40000 ALTER TABLE `register` ENABLE KEYS */;


--
-- Definition of table `sendmoney`
--

DROP TABLE IF EXISTS `sendmoney`;
CREATE TABLE `sendmoney` (
  `uname` varchar(40) NOT NULL,
  `name` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `acc_no` varchar(45) NOT NULL,
  `amount` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sendmoney`
--

/*!40000 ALTER TABLE `sendmoney` DISABLE KEYS */;
INSERT INTO `sendmoney` (`uname`,`name`,`ifsc`,`acc_no`,`amount`) VALUES 
 ('kkE+sPZhG3lRKTzF3JscUA==','V0WVJYCq2AYqEfVLhqxOog==','s9DqpcoJZdAGS9KABNj/iQ==','2CTCxhdgANqg+Eln2kYXRg==','6SmR7JVHQXLrWu8A0w+ehg==');
/*!40000 ALTER TABLE `sendmoney` ENABLE KEYS */;


--
-- Definition of table `testing`
--

DROP TABLE IF EXISTS `testing`;
CREATE TABLE `testing` (
  `idtesting` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`idtesting`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testing`
--

/*!40000 ALTER TABLE `testing` DISABLE KEYS */;
/*!40000 ALTER TABLE `testing` ENABLE KEYS */;


--
-- Definition of table `time_analysis`
--

DROP TABLE IF EXISTS `time_analysis`;
CREATE TABLE `time_analysis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme_name` varchar(45) NOT NULL,
  `false_time` int(11) NOT NULL,
  `true_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `time_analysis`
--

/*!40000 ALTER TABLE `time_analysis` DISABLE KEYS */;
INSERT INTO `time_analysis` (`id`,`scheme_name`,`false_time`,`true_time`) VALUES 
 (1,'pair_based',3,6),
 (2,'graphical_based',2,5),
 (3,'color_based',5,8);
/*!40000 ALTER TABLE `time_analysis` ENABLE KEYS */;


--
-- Definition of table `userregistration`
--

DROP TABLE IF EXISTS `userregistration`;
CREATE TABLE `userregistration` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `fullname` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  `emailid` varchar(45) DEFAULT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `point1` varchar(45) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `point2` varchar(45) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `point3` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `count` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

/*!40000 ALTER TABLE `userregistration` DISABLE KEYS */;
INSERT INTO `userregistration` (`username`,`password`,`fullname`,`address`,`mobileno`,`emailid`,`img1`,`point1`,`img2`,`point2`,`img3`,`point3`,`status`,`count`) VALUES 
 ('cOWhUJZZr49RJHfjzpkb9Q==','q7O0pvrERjALexpX331B0Q==','rHA59+AO0WPFfNQLIzGuuw==','vsstpfByFVWd8FhMHmQDXQ==','tYWd8nVG0/AgHYFBO9cq+g==','WzuvJGl3VXZhkgRGP0e2LQ==','Dataset/1.jpg','0#0','Dataset/17.jpg','0#0','Dataset/24.jpg','0#0','0','0'),
 ('kkE+sPZhG3lRKTzF3JscUA==','rgOTt++42SgKv7Rx2Z7FCg==','eTae8I77t2EnYeJqPTV8ng==','vsstpfByFVWd8FhMHmQDXQ==','tYWd8nVG0/AgHYFBO9cq+g==','owG2LgrrFlH2Uc3RromPykUkkdXz2cs3QW7EK7rmy7M=','Dataset/1.jpg','0#0','Dataset/10.jpg','10#6','Dataset/11.jpg','5#5','0','0');
/*!40000 ALTER TABLE `userregistration` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
