/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shouldersurfing;

import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.*;

public class LabelGrid extends JPanel {

    private static final int ROWS = 6;
    private static final int COLS = 8;
    private static final int GAP = 2;
    private JLabel[] buttonGrid = new JLabel[48];
    
    public LabelGrid() {
    }

    public LabelGrid(String label) {
        setLayout(new GridLayout(ROWS, COLS, GAP, GAP));
        // BufferedImage[] imgs = getImages();
        final String label1 = label;
        File fe = new File("Dataset");

        File lt[] = fe.listFiles();

        int count = 0;
        for (int row1 = 0; row1 < lt.length; row1++) {

            final int i1 = row1;
            final String imagename = lt[row1].getName();
            buttonGrid[row1] = new JLabel();
            File file = lt[row1]; // I have bear.jpg in my working directory
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            BufferedImage image = null;
            try {
                image = ImageIO.read(fis); //reading the image file
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            buttonGrid[row1].setIcon(new ImageIcon(Toolkit.getDefaultToolkit().createImage(image.getSource())));
            buttonGrid[row1].addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (label1.equals("1")) {
                        Details.img1 = "Dataset/"+imagename;;
                    } else if (label1.equals("2")) {
                        Details.img2 = "Dataset/"+imagename;
                    } else if (label1.equals("3")) {
                        Details.img3 = "Dataset/"+imagename;
                    }
                }
            });
            add(buttonGrid[row1]);
            count++;

        }
    }

    public void createAndShowGui(String label) {
        LabelGrid mainPanel = new LabelGrid(label);
        JFrame frame = new JFrame("Select Image From Dataset");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.getContentPane().add(mainPanel);
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            }
        });
    }
}
