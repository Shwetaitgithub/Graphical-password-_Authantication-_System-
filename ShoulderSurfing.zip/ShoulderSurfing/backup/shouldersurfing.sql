-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2021 at 11:23 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shouldersurfing`
--

-- --------------------------------------------------------

--
-- Table structure for table `addbeneficiary`
--

CREATE TABLE `addbeneficiary` (
  `username` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `nickname` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `b_Acc` varchar(45) NOT NULL,
  `pin_no` varchar(45) NOT NULL,
  `mobile_no` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addbeneficiary`
--

INSERT INTO `addbeneficiary` (`username`, `name`, `nickname`, `ifsc`, `b_Acc`, `pin_no`, `mobile_no`) VALUES
('kkE+sPZhG3lRKTzF3JscUA==', 'V0WVJYCq2AYqEfVLhqxOog==', 'WAkpze0cu2IXCo6kQUjl7Q==', 's9DqpcoJZdAGS9KABNj/iQ==', '2CTCxhdgANqg+Eln2kYXRg==', 'uBEMAAR3aLNBQlc0oJ1I3A==', 'PLvvlNdDl6U2xUZ74Uen7A==');

-- --------------------------------------------------------

--
-- Table structure for table `bankdetails`
--

CREATE TABLE `bankdetails` (
  `accno` varchar(100) NOT NULL,
  `bname` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `hname` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `age` varchar(45) NOT NULL,
  `panno` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `amount` varchar(45) NOT NULL,
  `dob` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bankdetails`
--

INSERT INTO `bankdetails` (`accno`, `bname`, `ifsc`, `type`, `hname`, `gender`, `age`, `panno`, `mobile`, `email`, `amount`, `dob`, `uname`) VALUES
('gFQXf8iBio0HQMRKPREJXw==', 'tyA4ta5NtylvNeifl9xhQw==', 'VGwmldeLzg5NtGdIaqGWZw==', '7FCzts3ZuMAyinkacO6KhQ==', 'eTae8I77t2EnYeJqPTV8ng==', 'HYkoxbD9Ts74J4NbvMKoBg==', 'SHD+UVuKh8PLGc7Qs7/OzA==', 'SHD+UVuKh8PLGc7Qs7/OzA==', 'tYWd8nVG0/AgHYFBO9cq+g==', 'owG2LgrrFlH2Uc3RromPykUkkdXz2cs3QW7EK7rmy7M=', 'owky2G7wdpBvnbMhoWewRQ==', 'kGryC8/e33PJoDTxrWIP23EqT9ENvL5ByoQI6/ZBwRc=', 'kkE+sPZhG3lRKTzF3JscUA==');

-- --------------------------------------------------------

--
-- Table structure for table `color_registration`
--

CREATE TABLE `color_registration` (
  `user_id` varchar(45) NOT NULL,
  `red_color` int(11) NOT NULL,
  `blue_color` int(11) NOT NULL,
  `green_color` int(11) NOT NULL,
  `pink_color` int(11) NOT NULL,
  `black_color` int(11) NOT NULL,
  `orange_color` int(11) NOT NULL,
  `cyan_color` int(11) NOT NULL,
  `magenta_color` int(11) NOT NULL,
  `user_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `color_registration`
--

INSERT INTO `color_registration` (`user_id`, `red_color`, `blue_color`, `green_color`, `pink_color`, `black_color`, `orange_color`, `cyan_color`, `magenta_color`, `user_status`) VALUES
('pramod', 2, 1, 3, 5, 4, 6, 7, 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `receivemoney`
--

CREATE TABLE `receivemoney` (
  `sname` varchar(200) DEFAULT NULL,
  `rname` varchar(45) DEFAULT NULL,
  `ifsc` varchar(45) DEFAULT NULL,
  `s_acc` varchar(45) DEFAULT NULL,
  `r_acc` varchar(45) DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receivemoney`
--

INSERT INTO `receivemoney` (`sname`, `rname`, `ifsc`, `s_acc`, `r_acc`, `amount`) VALUES
('aLmyBAYff/vcGZAUEv9ulw==', 'iji/sfAVausIPsrwxHy/jw==', 'LuoeFpaqgyOALdPQW57HIg==', 'GSFHKdjvRJJrs8HUHap1HA==', 'Gipxpl7iWL62b/ldd5suEA==', '6cLg06379TwqYpv/M45c7w=='),
('kkE+sPZhG3lRKTzF3JscUA==', 'V0WVJYCq2AYqEfVLhqxOog==', 's9DqpcoJZdAGS9KABNj/iQ==', 'gFQXf8iBio0HQMRKPREJXw==', '2CTCxhdgANqg+Eln2kYXRg==', '6SmR7JVHQXLrWu8A0w+ehg==');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Name` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `EmailId` varchar(50) NOT NULL,
  `MobileNo` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sendmoney`
--

CREATE TABLE `sendmoney` (
  `uname` varchar(40) NOT NULL,
  `name` varchar(45) NOT NULL,
  `ifsc` varchar(45) NOT NULL,
  `acc_no` varchar(45) NOT NULL,
  `amount` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sendmoney`
--

INSERT INTO `sendmoney` (`uname`, `name`, `ifsc`, `acc_no`, `amount`) VALUES
('kkE+sPZhG3lRKTzF3JscUA==', 'V0WVJYCq2AYqEfVLhqxOog==', 's9DqpcoJZdAGS9KABNj/iQ==', '2CTCxhdgANqg+Eln2kYXRg==', '6SmR7JVHQXLrWu8A0w+ehg==');

-- --------------------------------------------------------

--
-- Table structure for table `testing`
--

CREATE TABLE `testing` (
  `idtesting` int(10) UNSIGNED NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `time_analysis`
--

CREATE TABLE `time_analysis` (
  `id` int(11) NOT NULL,
  `scheme_name` varchar(45) NOT NULL,
  `false_time` int(11) NOT NULL,
  `true_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `time_analysis`
--

INSERT INTO `time_analysis` (`id`, `scheme_name`, `false_time`, `true_time`) VALUES
(1, 'pair_based', 3, 6),
(2, 'graphical_based', 2, 5),
(3, 'color_based', 5, 8);

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `username` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `fullname` varchar(45) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `mobileno` varchar(45) DEFAULT NULL,
  `emailid` varchar(45) DEFAULT NULL,
  `img1` varchar(100) DEFAULT NULL,
  `point1` varchar(45) DEFAULT NULL,
  `img2` varchar(100) DEFAULT NULL,
  `point2` varchar(45) DEFAULT NULL,
  `img3` varchar(100) DEFAULT NULL,
  `point3` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `count` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`username`, `password`, `fullname`, `address`, `mobileno`, `emailid`, `img1`, `point1`, `img2`, `point2`, `img3`, `point3`, `status`, `count`) VALUES
('cOWhUJZZr49RJHfjzpkb9Q==', 'q7O0pvrERjALexpX331B0Q==', 'rHA59+AO0WPFfNQLIzGuuw==', 'vsstpfByFVWd8FhMHmQDXQ==', 'tYWd8nVG0/AgHYFBO9cq+g==', 'WzuvJGl3VXZhkgRGP0e2LQ==', 'Dataset/1.jpg', '0#0', 'Dataset/17.jpg', '0#0', 'Dataset/24.jpg', '0#0', '0', '0'),
('kkE+sPZhG3lRKTzF3JscUA==', 'rgOTt++42SgKv7Rx2Z7FCg==', 'eTae8I77t2EnYeJqPTV8ng==', 'vsstpfByFVWd8FhMHmQDXQ==', 'tYWd8nVG0/AgHYFBO9cq+g==', 'owG2LgrrFlH2Uc3RromPykUkkdXz2cs3QW7EK7rmy7M=', 'Dataset/1.jpg', '0#0', 'Dataset/10.jpg', '10#6', 'Dataset/11.jpg', '5#5', '0', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addbeneficiary`
--
ALTER TABLE `addbeneficiary`
  ADD PRIMARY KEY (`b_Acc`);

--
-- Indexes for table `bankdetails`
--
ALTER TABLE `bankdetails`
  ADD PRIMARY KEY (`accno`,`uname`) USING BTREE;

--
-- Indexes for table `color_registration`
--
ALTER TABLE `color_registration`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`EmailId`);

--
-- Indexes for table `testing`
--
ALTER TABLE `testing`
  ADD PRIMARY KEY (`idtesting`);

--
-- Indexes for table `time_analysis`
--
ALTER TABLE `time_analysis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`username`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `testing`
--
ALTER TABLE `testing`
  MODIFY `idtesting` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `time_analysis`
--
ALTER TABLE `time_analysis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
